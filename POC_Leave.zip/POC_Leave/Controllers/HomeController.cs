﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Google.Apis.Calendar.v3;
using Google.Apis.Calendar.v3.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using MySql.Data.MySqlClient;
using POC_Leave.Models;


namespace POC_Leave.Controllers
{
    public class HomeController : Controller
    {


    private readonly ILogger<HomeController> _logger;
       
    public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            List<Employee> employee = new List<Employee>();

            using ( MySqlConnection con = new MySqlConnection("server=localhost;user=root;database=LeaveManagement;port=3306;password=Joburg.5947"))
            {
                con.Open();
                MySqlCommand cmd = new MySqlCommand("select * from Employee", con);
                MySqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {

                    Employee obj = new Employee();
                    obj.id = Convert.ToInt32(reader["id"]);
                    obj.FirstName = reader["FirstName"].ToString();
                    obj.LastName = reader["LastName"].ToString();
                    obj.startDate = Convert.ToDateTime(reader["StartDate"]);
                    obj.endDate = Convert.ToDateTime(reader["EndDate"]);
                    obj.LeaveType = reader["LeaveType"].ToString();
                    obj.LeaveReason = reader["LeaveReason"].ToString();
                    obj.LeaveDays = Convert.ToInt32(reader["LeaveDays"]);
                  
                   

                    employee.Add(obj);



                }

                reader.Close();
            }
            return View(employee);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        // [HttpPost]
        // [ValidateAntiForgeryToken]
        // public async Task<IActionResult> Create(
        //[Bind("")] Employee student)
        // {
        //  try
        //  {
        // if (ModelState.IsValid)
        //   {
        // _context.Add(student);
        // await _context.SaveChangesAsync();
        // return RedirectToAction(nameof(Index));
        // }
        //}
        // catch (DbUpdateException /* ex */)
        // {
        //     //Log the error (uncomment ex variable name and write a log.
        //  ModelState.AddModelError("", "Unable to save changes. " +
        //      "Try again, and if the problem persists " +
        //  "see your system administrator.");
        // }
        // return View(student);
        //  }


        // Creating a Google Calendar Event

        public IActionResult Event( DateTime start, DateTime end)
        {
                Event newEvent = new Event()
                {
                    Summary = "Google I/O 2015",
                    Location = "800 Howard St., San Francisco, CA 94103",
                    Description = "A chance to hear more about Google's developer products.",
                    Start = new EventDateTime()
                    {
                        DateTime = DateTime.Parse("2015-05-28T09:00:00-07:00"),
                        TimeZone = "America/Los_Angeles",
                    },
                    End = new EventDateTime()
                    {
                        DateTime = DateTime.Parse("2015-05-28T17:00:00-07:00"),
                        TimeZone = "America/Los_Angeles",
                    },
                    Recurrence = new String[] { "RRULE:FREQ=DAILY;COUNT=2" },
                    Attendees = new EventAttendee[] {
                    new EventAttendee() { Email = "u16278055@tuks.co.za" },
                    new EventAttendee() { Email = "sbrin@example.com" },
                     },

                    Reminders = new Event.RemindersData()
                    {
                        UseDefault = false,
                        Overrides = new EventReminder[] {
                        new EventReminder() { Method = "email", Minutes = 24 * 60 },
                        new EventReminder() { Method = "sms", Minutes = 10 },
                         }
                    }
                };

                //String calendarId = "primary";
                //EventsResource.InsertRequest request = service.Events.Insert(newEvent, calendarId);
               
                //Event createdEvent = request.Execute();
                //Console.WriteLine("Event created: {0}", createdEvent.HtmlLink);

            return Redirect("Index");
            

        }
      
        // Adding a new Leave Request
        [HttpPost]
        public IActionResult Add(Employee employee)
        {
            

            using (MySqlConnection cn = new MySqlConnection("server=localhost;user=root;database=LeaveManagement;port=3306;password=Joburg.5947"))
            {
                
                
                    //string query = "INSERT INTO Employee(user_id, user_name) VALUES (?user_id,?user_name);";
                    cn.Open();

                    string Query = "INSERT INTO LeaveManagement.Employee (FirstName, LastName, StartDate, EndDate, LeaveType, LeaveReason, LeaveDays) VALUES (?FirstName,?LastName,?StartDate, ?EndDate,?LeaveType,?LeaveReason,?LeaveDays); ";
                   
                    using (MySqlCommand cmd = new MySqlCommand(Query, cn))
                    {
                      
                        cmd.Parameters.Add("?FirstName", MySqlDbType.String).Value = "FirstName";
                        cmd.Parameters.Add("?LastName", MySqlDbType.String).Value = "LastName";
                        cmd.Parameters.Add("?StartDate", MySqlDbType.DateTime).Value = "StartDate";
                        cmd.Parameters.Add("?EndDate", MySqlDbType.DateTime).Value = "EndDate";
                        cmd.Parameters.Add("?LeaveType", MySqlDbType.VarChar).Value = "LeaveType";
                        cmd.Parameters.Add("?LeaveReason", MySqlDbType.VarChar).Value = "LeaveReason";
                        cmd.Parameters.Add("?LeaveDays", MySqlDbType.Int32).Value = "LeaveDays";
                        
                        cmd.ExecuteNonQuery();

                        cn.Close();
                    }
                
                
            }

            // Event(StartDate, EndDate)

            return Redirect("Index");
        }

        
    }
}
